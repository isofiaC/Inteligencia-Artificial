# -*- coding: utf-8 -*-
"""
Inteligência Computacional - Fase II - 2022/2023
Inês Carvalho - 2017015276
Rui Gonçalves – 2015014039
"""

import SwarmPackagePy
from SwarmPackagePy import testFunctions as tf
"""
ackley_function
sphere_function
"""
Particulas = [5, 10, 20, 40]
funcao = tf.ackley_function
limInf = -40
limSup = 40
dimensao = 3
iteracoes = [100, 1000, 10000]
w = [0.4, 0.9] 
c1 = [3, 1.6]
c2 =[2.4, 2.8]


#72 testes = 3x3x2x2x2

print('Função ', funcao)

for i in Particulas:
    print()
    print("---------------------------")
    print ("Número de partículas: ", i)
    print("---------------------------")
    print()
    np = int(i)
    for j in c1:
        print()
        print('c1 = ', j)
        print('_____________________________')
        nc1 = int(j)
        for k in c2:
            print()
            print('c2 = ', k)
            print('_____________________________')
            nc2 = int(j)
            for h in w:
                print()
                print('w = ', h)
                print('_____________________________')
                nw = int(h)
                for l in iteracoes:
                    print('Iterações: ', l)
                    nIteracoes = int(l)
                    pso = SwarmPackagePy.pso(np, funcao, limInf, limSup, dimensao, nIteracoes,nw, nc1, nc2)
                    print ("Melhor Solução: ", pso.get_Gbest())  
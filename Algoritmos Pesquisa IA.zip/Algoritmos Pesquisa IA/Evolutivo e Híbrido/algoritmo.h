#define MAX_OBJ 500

// EStrutura para armazenar parametros
struct info
{
    // Tamanho da popula��o
    int     popsize;
    // Probabilidade de muta��o
    float   pm;
    // Probabilidade de recombina��o
    float   pr;
    // Tamanho do torneio para sele��o do pai da pr�xima gera��o
	int     tsize;
	// N�mero vertices
    int     numVertices;
	// N�mero de gera��es
    int     numGenerations;
    // N�mero de gera��es
    int     numArestas;
};

// Individuo (solu��o)
typedef struct individual chrom, *pchrom;

struct individual
{
    // Solu��o
    int     p[MAX_OBJ];
    // Valor da qualidade da solu��o do individuo
	int   fitness;
};

void tournament_geral(pchrom pop, struct info d, pchrom parents);

void genetic_operators(pchrom, struct info, pchrom);

void recombinacao(pchrom parents, struct info d, pchrom offspring);

void crossover(int p1[], int p2[], int d1[], int d2[], struct info d);

void mutation(pchrom, struct info);

void mutacao_por_troca(pchrom, struct info);

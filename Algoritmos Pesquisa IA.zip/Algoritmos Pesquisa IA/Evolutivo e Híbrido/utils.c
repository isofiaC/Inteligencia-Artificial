#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "algoritmo.h"
#include "utils.h"

// Inicializa��o do gerador de n�meros aleat�rios
void init_rand()
{
	srand((unsigned)time(NULL));
}

// Leitura dos par�metros e dos dados do problema
// Par�metros de entrada: Nome do ficheiro e matriz a preencher
// Par�metros de sa�da: Devolve a estrutura com os par�metros
struct info init_data(char *filename, int mat[][MAX_OBJ])
{
	struct  info x;
	FILE    *f;
	int     i, j, k;
	char    str[100];

	f = fopen(filename, "rt");
	if (!f)
	{
		printf("File not found\n");
		exit(1);
	}

	x.popsize        = 50; // Tamanho da popula��o
	x.pr             = 0.7; // Probabilidade de recombina��o
    x.pm             = 0.05; // Probabilidade de muta��o
	x.tsize          = 10;   // Tamanho do torneio para sele��o do pai da pr�xima gera��o
	x.numGenerations = 2500;// N�mero de gera��es
	fscanf(f,"%[^\n]", str);
	// Numero de vertices
	fscanf(f, "%d", &x.numVertices);
	// Numero de vertices
	fscanf(f, "%d", &x.numVertices);
	// Numero de arestas
	fscanf(f, "%d", &x.numArestas);
	if (x.numVertices > MAX_OBJ)
	{
		printf("Number of itens is superior to MAX_OBJ\n");
		exit(1);
	}
	// Preenchimento da matriz
	for(i=0; i<x.numVertices; i++)
        for(j=0; j<x.numVertices; j++)
            mat[i][j]=0;
	for(i=0; i<x.numArestas; i++)
	{
        fscanf(f, "%d %d", &j, &k);
        mat[j-1][k-1]=1;
        mat[k-1][j-1]=1;
    }
	fclose(f);
	// Devolve a estrutura com os par�metros
	return x;
}

void swap (int *a, int *b)
{
    int x;

    x=*a;
    *a=*b;
    *b=x;
}

// Criacao da populacao inicial. O vector e alocado dinamicamente
// Par�metro de entrada: Estrutura com par�metros do problema
// Par�metro de sa�da: Preenche da estrutura da popula��o
pchrom init_pop(struct info d)
{
	int     i, j;
	pchrom  indiv;

	indiv = malloc(sizeof(chrom)*d.popsize);
	if (indiv==NULL)
	{
		printf("Erro na alocacao de memoria\n");
		exit(1);
	}
	for (i=0; i<d.popsize; i++)
	{
		for (j=0; j<d.numVertices; j++)
			indiv[i].p[j] = j+1;
        for (j=d.numVertices-1; j>=0; j--)
			swap(&indiv[i].p[j], &indiv[i].p[random_l_h(0, d.numVertices-1)]);
	}
	return indiv;
}

// Actualiza a melhor solu��o encontrada
// Par�metro de entrada: populacao actual (pop), estrutura com par�metros (d) e a melhor solucao encontrada at� a gera��oo imediatamente anterior (best)
// Par�metro de sa�da: a melhor solucao encontrada at� a gera��o actual
chrom get_best(pchrom pop, struct info d, chrom best)
{
	int i;

	for (i=0; i<d.popsize; i++)
	{
		if (best.fitness > pop[i].fitness)
			best=pop[i];
	}
	return best;
}

// Devolve um valor inteiro distribuido uniformemente entre min e max
int random_l_h(int min, int max)
{
	return min + rand() % (max-min+1);
}

// Devolve um valor real distribuido uniformemente entre 0 e 1
float rand_01()
{
	return ((float)rand())/RAND_MAX;
}

// Escreve uma solu��o na consola
// Par�metro de entrada: populacao actual (pop) e estrutura com par�metros (d)
void write_best(chrom x, struct info d)
{
	int i;


	for (i=0; i<d.numVertices; i++)
		printf("%d ", x.p[i]);
    printf("\n\tQualidade: %d\n", x.fitness);

}

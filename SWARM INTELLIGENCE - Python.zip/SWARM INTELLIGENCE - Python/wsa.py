# -*- coding: utf-8 -*-
"""
Inteligência Computacional - Fase II - 2022/2023
Inês Carvalho - 2017015276
Rui Gonçalves – 2015014039
"""

import SwarmPackagePy
from SwarmPackagePy import testFunctions as tf
"""
ackley_function
sphere_function
"""
Particulas = [5, 10, 20, 40]
funcao = tf.sphere_function
limInf = -10
limSup = 80
dimensao = 3
iteracoes = [100, 1000, 10000]
rho = [1, 3, 6]
eta = [0.1, 0.01, 0.001]


#81 testes = 3x3x3x3


print('Função ', funcao)

for i in Particulas:
    print()
    print('*****************************')
    print("Numero de partículas: ", i)
    print('*****************************')
    print()
    np = int(i)
    for j in rho:
        print()
        print('rho = ', j)
        print('_____________________________')
        nRho = int(j)
        for k in eta:
            print()
            print('eta = ', k)
            print('_ _ _ _ _ _ _ _ _ _ _ _ _ _ _')
            nEta = int(k)
            for l in iteracoes: 
                print('Iterações: ', l)
                nIteracoes = int(l)
                wsa=SwarmPackagePy.wsa(np, funcao, limInf, limSup, dimensao, nIteracoes, nRho, nEta)
                print('Melhor solução: ',wsa.get_Gbest())
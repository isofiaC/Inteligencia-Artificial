""" 
Inteligencia Computacional
2022/23
Trabalho Pratico
Fase III - Otimizacao do Modelo
Wave Energy Converters Data Set
Ines Carvalho -�� 2017015276
Rui Goncalves -�� 2015014039
"""



## Importar bibliotecas
# Importar bibliotecas Pandas, NumPy, Matplotlib, Random, Math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math

# Importar bibliotecas PySwarms
import pyswarms as ps
from pyswarms.utils.functions import single_obj as fx
from pyswarms.utils.plotters import plot_cost_history

# Importar bibliotecas Scikit-Learn
from sklearn import metrics
from sklearn import model_selection
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler

# Importar bibliotecas TensorFlow
import tensorflow as tf

# Importar bibliotecas Keras
from keras.models import Sequential
from keras.optimizers import Adam



## Preparar dataset
# Ler dados a partir do ficheiros dataset.csv
dataset = pd.read_csv('data/dataset.csv')

# Dividir o dataset entre inputs (X) e outputs (Y)
X = np.array(dataset.iloc[:, 0:48])
y = np.array(dataset.iloc[:, 48])

# Fazer a divis�o entre treino (70%) e teste (30%)
X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y,
                                             test_size=0.3, random_state=42)

# Normalizar os valores
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.fit_transform(X_test)


## Otimizar hiper-parametros em PSO
c1 = [0.3, 0.5, 0.7]
c2 = [0.3, 0.5, 0.7]

for a in c1:
    for b in c2:
        options = {'c1': a, 'c2': b, 'w':0.9}
        # Chamar inst�ncia de PSO
        optimizer = ps.single.GlobalBestPSO(n_particles=10, dimensions=2, options=options)
        
        # Realizar optimizacao
        cost, pos = optimizer.optimize(fx.sphere, iters=1000)
        
        if a == 0.3 and b == 0.3:
            min_cost = cost
            best_pos = pos
            best_c1 = a
            best_c2 = b
        elif cost < min_cost:
            min_cost = cost
            best_pos = pos
            best_c1 = a
            best_c2 = b

options = {'c1': best_c1, 'c2': best_c2, 'w':0.9}
optimizer = ps.single.GlobalBestPSO(n_particles=10, dimensions=2, options=options)
cost, pos = optimizer.optimize(fx.sphere, iters=1000)

print('\nApos otimizacao de hiper-parametros: ')
print('c1 = ', best_c1)
print('c2 = ', best_c2)

# Mostrar grafico
plot_cost_history(optimizer.cost_history)
plt.show()



## SVR - Regressao com pesquisa em grelha
# Definir parametros para treino
parameters = {'kernel':('linear', 'rbf'), 'C':[1, 10]}
regr = SVR()
regr = model_selection.GridSearchCV(regr, parameters)
regr.fit(X_train, y_train)
print(sorted(regr.cv_results_.keys()))
y_predicted = regr.predict(X_test)

# Calcular as metricas
print('\nMetricas para SVR com pesquisa em grelha: ')
print('MAE: ', metrics.mean_absolute_error(y_test, y_predicted))
print('MSE: ', metrics.mean_squared_error(y_test, y_predicted))
print('RMSE: ', math.sqrt(metrics.mean_squared_error(y_test, y_predicted)))
print('R2: ', metrics.r2_score(y_test, y_predicted))      



## Instanciar uma rede neuronal profunda em tf.keras com CNN 1D
model = Sequential()

# C1 Camada de convolucao
model.add(tf.keras.layers.Conv1D(10, kernel_size=5, strides=1, activation='tanh',
                                 input_shape=(48,1), padding='same'))

# S2 Camada de agrupamento
model.add(tf.keras.layers.AveragePooling1D(pool_size=2, strides=1, padding='valid'))

# C3 Camada de convolucao
model.add(tf.keras.layers.Conv1D(20, kernel_size=5, strides=1, activation='tanh',
                                 padding='valid'))

# S4 Camada de agrupamento
model.add(tf.keras.layers.AveragePooling1D(pool_size=2, strides=2, padding='valid'))

# C5 Camada de convolucao totalmente conectada
model.add(tf.keras.layers.Conv1D(50, kernel_size=5, strides=1, activation='tanh',
                                 padding='valid'))

# Achatar a saida CNN para a podermos ligar as camadas totalmente conectadas
model.add(tf.keras.layers.Flatten())

# Acrescentar camadas totalmente conectadas
model.add(tf.keras.layers.Dense(50, activation='relu'))
model.add(tf.keras.layers.Dense(50, activation='relu'))

# Adam optimizer com learning rate de 0.001
optimizer = Adam(learning_rate=0.001)
model.compile(optimizer, loss='mse', metrics=[tf.keras.metrics.MeanSquaredError()])

# Treinar o model
model.fit(X_train, y_train, verbose=1, batch_size=5, epochs=100)

# Testar o modelo
results = model.evaluate(X_test, y_test)

print('\nResumo do Modelo da Rede Neuronal Densa: ')
print(model.summary())



# Gravar modelo
model.save('modelo')

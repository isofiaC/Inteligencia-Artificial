#define _CRT_SECURE_NO_WARNINGS 1
#include "algoritmo.h"
#include "funcao.h"
#include "utils.h"

#define GENERATIONS_TC  150


// Calcula a qualidade de uma solu��o
// Par�metros de entrada: solu��o (sol), informa��o sobre o grafo (d), matriz com dados do problema (mat)
// Par�metros de sa�da: qualidade da solu��o
float eval_individual(int sol[], struct info d, int mat[][MAX_OBJ])
{

    int custo = 0;
	int i, j, aux;

	for (i = 0; i < d.numVertices; i++)
    {
        for (j=0; j<d.numVertices; j++)
        {
           if((mat[i][j])==1)
           {
               aux = abs(sol[j]-sol[i]);

               if(aux>custo)
                custo=aux;
           }
        }
    }
	return custo;
}

// Avaliacao da popula��o
// Par�metros de entrada: populacao (pop), estrutura com parametros (d) e matriz com dados do problema (mat)
// Par�metros de sa�da: Preenche pop com os valores de fitness e de validade para cada solu��o
void evaluate(pchrom pop, struct info d, int mat[][MAX_OBJ])
{
	int i;

	for (i=0; i<d.popsize; i++)
		pop[i].fitness = eval_individual(pop[i].p, d, mat);

}

void gera_vizinho(int a[], int b[], int mat[][MAX_OBJ], int n)
{
    int i, p1, p2,p3, p4, aux;

    for( i=0; i<n; i++)
        b[i]=a[i];
    p1 = random_l_h(0, n-1);
    do{
        p2 = random_l_h(0, n-1);
    }while(p1==p2);
    aux=b[p1];
    b[p1]=b[p2];
    b[p2]=aux;
    do{
        p3 = random_l_h(0, n-1);
    }while (p3==p1 || p3==p2);
    do{
        p4 = random_l_h(0, n-1);
    }while (p4==p1 || p4==p2 || p4 == p3);
    aux=b[p3];
    b[p3]=b[p4];
    b[p4]=aux;
}

void trepa_colinas(pchrom pop, struct info d, int mat[][MAX_OBJ])
{
    int     i, j;
    chrom   vizinho;

    for (i=0; i<d.popsize; i++)
    {
        for (j=0; j<GENERATIONS_TC; j++)
        {
            gera_vizinho(pop[i].p, vizinho.p,mat, d.numVertices);
            vizinho.fitness = eval_individual(vizinho.p, d, mat);
            if (vizinho.fitness <= pop[i].fitness)
                pop[i] = vizinho;
        }
    }
}

#define MAX_OBJ 1000
void gera_vizinho(int a[], int b[], int n);
int trepa_colinas_probabilistico(int sol[], int *mat, int vert, int num_iter);
void gera_vizinho2(int a[], int b[], int n);


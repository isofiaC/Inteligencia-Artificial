#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include "algoritmo.h"
#include "utils.h"

// Preenche uma estrutura com os progenitores da pr�xima gera��o, de acordo com o resultados do torneio
// Par�metros de entrada: popula��o actual (pop), estrutura com par�metros (d) e popula��o de pais a encher
void tournament_geral(pchrom pop, struct info d, pchrom parents)
{
    int i, j, k, sair, best, *pos;

    pos = malloc(d.tsize*sizeof(int));
    // Realiza popsize torneios
    for(i=0; i<d.popsize; i++)
    {
        // Seleciona tsize solu��es diferentes para entrarem em torneio de sele��o
        for(j=0; j<d.tsize; j++)
        {
            do
            {
                pos[j] = random_l_h(0, d.popsize-1);
                // Verifica se a nova posi��o escolhida � igual a alguma das outras posi��es escolhidas
                sair = 0;
                for (k=0; k<j; k++)
                {
                    if (pos[k]==pos[j])
                        sair = 1;
                }
            }
            while (sair);
            // Guarda a posi��o da melhor solu��o de todas as que entraram em torneio
            if (j==0 || pop[pos[j]].fitness < pop[pos[best]].fitness)
                best = j;
        }
        parents[i] = pop[pos[best]];
    }
    free(pos);
}

// Operadores geneticos a usar na gera��o dos filhos
// Par�metros de entrada: estrutura com os pais (parents), estrutura com par�metros (d), estrutura que guardar� os descendentes (offspring)
void genetic_operators(pchrom parents, struct info d, pchrom offspring)
{
    // Recombina��o por ordem/corte
	recombinacao(parents, d, offspring);
    // Muta��o por troca
    mutacao_por_troca(offspring, d);
	// Muta��o por invercao
   // mutation(offspring, d);
}

void recombinacao(pchrom parents, struct info d, pchrom offspring){
int i;

	for (i=0; i<d.popsize; i+=2)
	{
		if (rand_01() < d.pr)
		{
			crossover((parents+i) -> p, (parents+i+1) -> p, (offspring+i)-> p, (offspring+i+1) -> p, d);
		}
		else
		{
			offspring[i] = parents[i];
			offspring[i+1] = parents[i+1];
		}
		(offspring+i) ->fitness = (offspring+i+1) ->fitness = 0.0;
	}
}
//p1 pai 1; p2 pai2; d1 filho 1; d2 filho 2
// Recombina��o por ordem
void crossover(int p1[], int p2[], int d1[], int d2[], struct info d)
{
	int i, point1, point2, index;
	int tab1[MAX_OBJ+1]={0}, tab2[MAX_OBJ+1]={0};

            point1 = random_l_h(0, d.numVertices-1);
    do{
        point2 = random_l_h(0, d.numVertices-1);
    }while (point1 == point2);
    if (point1 > point2)
    {
        i = point1;
        point1 = point2;
        point2 = i;
    }
    //copia das seccoes internas
    for (i = point1; i<=point2; i++)
    {
        d1[i]=p1[i];
        tab1[p1[i]]=1;
        d2[i]=p2[i];
        tab2[p2[i]]=1;
    }
    // preencher o resto do descendente 1
    index = (point2+1)%d.numVertices;
    for (i=point2+1; i<d.numVertices; i++)
    {
        if (tab1[p2[i]]==0)
        {
            d1[index]=p2[i];
            index = (index+1)%d.numVertices;
        }
    }
    for (i=0; i<=point2; i++)
    {
        if (tab1[p2[i]]==0)
        {
            d1[index]=p2[i];
            index = (index+1)%d.numVertices;
        }
    }
    // preencher o resto do descendente 1
    index = (point2+1)%d.numVertices;
    for (i=point2+1; i<d.numVertices; i++)
    {
        if (tab2[p1[i]]==0)
        {
            d2[index]=p1[i];
            index = (index+1)%d.numVertices;
        }
    }
    for (i=0; i<=point2; i++)
    {
        if (tab2[p1[i]]==0)
        {
            d2[index]=p1[i];
            index = (index+1)%d.numVertices;
        }
    }
}

// Muta��o por troca
// Par�metros de entrada: estrutura com os descendentes (offspring) e estrutura com par�metros (d)
void mutacao_por_troca(pchrom offspring, struct info d)
{
	int i, pos1, pos2, aux;

	for (i=0; i<d.popsize; i++)
        if (rand_01() < d.pm)
        {

                pos1 = random_l_h(0, d.numVertices-1);
            do
                pos2 = random_l_h(0, d.numVertices-1);

            while (pos2==pos1);
            aux = offspring[i].p[pos1];
            offspring[i].p[pos1] = offspring[i].p[pos2];
            offspring[i].p[pos2] = aux;
        }
}


// Muta��o por inversao
// Par�metros de entrada: estrutura com os descendentes (offspring) e estrutura com par�metros (d)
void mutation(pchrom offspring, struct info d)
{
	int i, pos1, pos2, aux;

	for (i=0; i<d.popsize; i++)
			if (rand_01() < d.pm)
            {
                pos1 = random_l_h(0, d.numVertices-1);

            if(pos1==d.numVertices-1)
                pos2=0;
            else
                pos2=pos1+1;
                aux=offspring[i].p[pos1];
                offspring[i].p[pos1]=offspring[i].p[pos2];
                offspring[i].p[pos2]=aux;
            }
}

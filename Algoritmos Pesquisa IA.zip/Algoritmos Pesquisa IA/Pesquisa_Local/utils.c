#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "utils.h"


// Leitura do ficheiro de input
// Recebe: nome do ficheiro, numero de vertices (ptr)
// Devolve a matriz de adjacencias
int* init_dados(char *nome, int *n)
{
	FILE    *f;
	int     *p;
	int     a, i, j, k;
	char    str[100];

	f=fopen(nome, "r");
	if(!f)
	{
		printf("Erro no acesso ao ficheiro dos dados\n");
		exit(1);
	}
	fscanf(f,"%[^\n]", str);
	// Numero de vertices
	fscanf(f, "%d", n);
	// Numero de vertices
	fscanf(f, "%d", n);
	// Numero de arestas
	fscanf(f, "%d", &a);
	// Alocacao dinamica da matriz
	p = malloc(sizeof(int)*(*n)*(*n));
	if(!p)
	{
	    printf("Erro na alocacao de memoria\n");
	    exit(1);
	}
	// Preenchimento da matriz
	for(i=0; i<*n; i++)
        for(j=0; j<*n; j++)
            *(p+(*n)*i+j)=0;
	for(i=0; i<a; i++)
	{
        fscanf(f, "%d %d", &j, &k);
        *(p+(*n)*(j-1)+k-1)=1;
        *(p+(*n)*(k-1)+j-1)=1;
    }
	fclose(f);
	return p;
}

// Gera a solucao inicial
// Parametros: solucao, numero de vertices
void gera_sol_inicial(int *sol, int v)
{
	int i, aux, p1, p2;

	for(i=0; i<v; i++)
    {
        sol[i]=i+1;
    }
     p1 = random_l_h(0, v-1);

     do
        p2 = random_l_h(0, v-1);
    while(p2==p1);
        aux=sol[p1];
        sol[p1]=sol[p2];
        sol[p2]=aux;
}

// Escreve solucao
// Parametros: solucao e numero de vertices
void escreve_sol(int *sol, int vert)
{
	int i;
	printf("\nSolucao: ");
	for(i=0; i<vert; i++)
        printf("%2d  ", sol[i]);
	printf("\n");
}

// copia vector b para a (tamanho n)
void substitui(int a[], int b[], int n)
{
    int i;
    for(i=0; i<n; i++)
        a[i]=b[i];
}

// Inicializa o gerador de numeros aleatorios
void init_rand()
{
	srand((unsigned)time(NULL));
}

// Devolve valor inteiro aleatorio entre min e max
int random_l_h(int min, int max)
{
	return min + rand() % (max-min+1);
}

// Devolve um valor real aleatorio do intervalo [0, 1]
float rand_01()
{
	return ((float)rand())/RAND_MAX;
}
/*
// Actualiza a melhor solu��o encontrada
// Par�metro de entrada: populacao actual (pop), estrutura com par�metros (d) e a melhor solucao encontrada at� a gera��oo imediatamente anterior (best)
// Par�metro de sa�da: a melhor solucao encontrada at� a gera��o actual
chrom get_best(pchrom pop, struct info d, chrom best)
{
	int i;

	for (i=0; i<d.popsize; i++)
	{
		if (best.fitness > pop[i].fitness)
			best=pop[i];
	}
	return best;
}*/

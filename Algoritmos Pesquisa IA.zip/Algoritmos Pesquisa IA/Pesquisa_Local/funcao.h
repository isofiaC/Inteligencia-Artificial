int calcula_fit(int a[], int *mat, int vert);

void evaluate(pchrom, struct info, int mat[][MAX_OBJ]);

void trepa_colinas(pchrom, struct info, int mat[][MAX_OBJ]);

void gera_vizinho(int a[], int b[], int mat[][MAX_OBJ], int n);

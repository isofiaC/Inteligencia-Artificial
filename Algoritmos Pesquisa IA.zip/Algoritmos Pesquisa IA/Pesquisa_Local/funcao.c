#include "funcao.h"

// Calcula a qualidade de uma solu��o
// Par�metros de entrada: Solu��o actual, a, Matriz de adjac�ncias, mat, N�mero de v�rtices, vert
// Par�metros de sa�da: Custo, total - Neste caso, � o n�mero de liga��es que existem entre os v�rtices
int calcula_fit(int a[], int *mat, int vert)
{
	int custo = 0;
	int i, j, aux=0;

	for (i = 0; i < vert; i++)
    {
        for (j=0; j<vert; j++)
        {
           if(*(mat+vert*i+j)==1)
           {
               aux=abs(a[i]-a[j]);

               if(aux>custo)
                custo=aux;
           }
        }
    }
	return custo;
}
